﻿sswapp.controller('VOCReportModel', ['$scope', '$location', '$http', 'sharedService', 'uiGridConstants', function ($scope, $location, $http, sharedService,uiGridConstants) {
    $scope.showProcDisp;
    $scope.VOCData;
    $scope.reptype;
    $scope.catgWiseData = [];
    $scope.yearmonthwise = [];
    $scope.appwise = [];
    $scope.regionwise = [];
    $scope.CatgGridOpt = {
        data: 'catgWiseData',
        enableColumnResize: true,
        multiSelect: false,
        columnDefs: [
        { field: 'FeedResponse', displayName: 'Response' },
        { field: 'FeedRespCnt', displayName: 'Count' }]
    };
    $scope.YearMonthgrdopt = {
        data: 'yearmonthwise',
        enableColumnResize: true,
        multiSelect: false,
        columnDefs: [
        { field: 'year', displayName: 'Year' },
        { field: 'jan', displayName: 'Jan' },
        { field: 'feb', displayName: 'Feb' },
        { field: 'mar', displayName: 'Mar' },
        { field: 'apr', displayName: 'Apr' },
        { field: 'may', displayName: 'May' },
        { field: 'jun', displayName: 'Jun' },
        { field: 'jul', displayName: 'Jul' },
        { field: 'aug', displayName: 'Aug' },
        { field: 'sep', displayName: 'Sep' },
        { field: 'oct', displayName: 'Oct' },
        { field: 'nov', displayName: 'Nov' },
        { field: 'dec', displayName: 'Dec' }],

    };
    $scope.Appgrdopt = {
        data: 'appwise',
        enableColumnResize: true,
        multiSelect: false,
        columnDefs: [
        { field: 'AppName', displayName: 'AppName' },
        { field: 'total', displayName: 'Total' },
        { field: 'Great', displayName: 'Great' },
        { field: 'Good', displayName: 'Good' },
        { field: 'Average', displayName: 'Average' },
        { field: 'Below_Average', displayName: 'Below_Average' },
        { field: 'Bad', displayName: 'Bad' }],

    };
    $scope.Regiongrdopt = {
        data: 'regionwise',
        enableColumnResize: true,
        multiSelect: false,
        columnDefs: [
        { field: 'region', displayName: 'Region' },
        { field: 'total', displayName: 'Total' },
        { field: 'Great', displayName: 'Great' },
        { field: 'Good', displayName: 'Good' },
        { field: 'Average', displayName: 'Average' },
        { field: 'Below_Average', displayName: 'Below_Average' },
        { field: 'Bad', displayName: 'Bad' }],

    };


    $("#vocfeed").css('visibility', 'hidden');
    $("#vocyearmon").css('visibility', 'hidden');
    $("#vocapp").css('visibility', 'hidden');
    $("#vocRegion").css('visibility', 'hidden');
    $scope.RepTypeClick = function (rtype) {
        $scope.reptype = rtype;
        $('#formtitle').text("");
        $("#reptypeform").hide();
        switch (rtype) {
            case 'User':
                $("#vocfeed").show();
                $scope.showProcDisp = sharedService.openWithoutOverlay();
                $scope.getVocData($scope.showProcDisp);
                ShowHideFormnavbar(true);
                $("#vocfeed").css('visibility', 'visible');
                break;
            case 'YearMonth':
                $("#vocyearmon").show();
                $scope.showProcDisp = sharedService.openWithoutOverlay();
                $scope.getVocData($scope.showProcDisp);
                ShowHideFormnavbar(true);
                $("#vocyearmon").css('visibility', 'visible');
                break;
            case 'Application':
                $("#vocapp").show();
                $scope.showProcDisp = sharedService.openWithoutOverlay();
                $scope.getVocData($scope.showProcDisp);
                ShowHideFormnavbar(true);
                $("#vocapp").css('visibility', 'visible');
                break;
            case 'Region':
                $("#vocRegion").show();
                $scope.showProcDisp = sharedService.openWithoutOverlay();
                $scope.getVocData($scope.showProcDisp);
                ShowHideFormnavbar(true);
                $("#vocRegion").css('visibility', 'visible');
                break;
            default:
                //do nothing
        }

    }
    $scope.getVocData = function (showproc) {
        $http.get("VOCReport/GetVOCReport", {
            params: {}
        }).
              success(function (data) {
                  showproc.close();
                  var jsStr = JSON.stringify(data);
                  $scope.VOCData = $.parseJSON(jsStr);
                
                  switch ($scope.reptype) {
                      case 'User':
                          $('#formtitle').text("User Response wise ");
                          $("#FBCatgDetails").show();
                          $scope.LoadAnalysisDetails();
                          break;
                      case 'YearMonth':
                          $('#formtitle').text("Yearly/Monthly Feedback Received ");
                          $("#vocyearmon").show();
                          $scope.yearmonthwise();
                          break;
                      case 'Application':
                          $('#formtitle').text("Application wise Response ");
                          $("#vocapp").show();
                          $scope.Applicationwise();
                          break;
                      case 'Region':
                          $('#formtitle').text("Region Wise Response ");
                          $("#vocRegion").show();
                          $scope.Regionwise();
                          break;
                  }
                  

              }).error(function (data, status, headers, config) {
                  alert("error");
                  return status;
              });
    };
    $scope.Regionwise = function () {
        $scope.regionwise = $scope.VOCData["regionwise"];

        var chart = Highcharts.chart('RegionChart', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Region wise Response(Top 10)'
            },
            xAxis: {
                categories: []
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Count(in nos)'
                },
                stackLabels: {
                    enabled: true,
                    style: {
                        fontWeight: 'bold',
                        color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
                    }
                }
            },
            legend: {
                align: 'right',
                x: -30,
                verticalAlign: 'top',
                y: 25,
                floating: true,
                backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
                borderColor: '#CCC',
                borderWidth: 1,
                shadow: false
            },
            tooltip: {
                headerFormat: '<b>{point.x}</b><br/>',
                pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}'
            },
            credits: {
                enabled: false
            },
            plotOptions: {
                column: {
                    stacking: 'normal',
                    dataLabels: {
                        enabled: true,
                        color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
                    }
                }
            },
            series: []
        });
        var categories = chart.xAxis[0].categories;
        var greatarr = [];
        var goodarr = [];
        var Averagearr = [];
        var Below_Averagearr = [];
        var Badarr = [];
        for (i = 0; i < 10; i++) {
            data = $scope.regionwise[i];
            categories.push(data.region);
            greatarr.push(data.Great);
            goodarr.push(data.Good);
            Averagearr.push(data.Average);
            Below_Averagearr.push(data.Below_Average);
            Badarr.push(data.Bad);
        }
        chart.addSeries({
            name: 'Great',
            data: greatarr
        });
        chart.addSeries({
            name: 'Good',
            data: goodarr
        });
        chart.addSeries({
            name: 'Average',
            data: Averagearr
        });
        chart.addSeries({
            name: 'Below_Average',
            data: Below_Averagearr
        });
        chart.addSeries({
            name: 'Bad',
            data: Badarr
        });
    };
    $scope.Applicationwise = function () {
        $scope.appwise = $scope.VOCData["Appwise"];

        var chart = Highcharts.chart('AppChart', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Application wise Response(Top 10)'
            },
            xAxis: {
                categories: []
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Count(in nos)'
                },
                stackLabels: {
                    enabled: true,
                    style: {
                        fontWeight: 'bold',
                        color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
                    }
                }
            },
            legend: {
                align: 'right',
                x: -30,
                verticalAlign: 'top',
                y: 25,
                floating: true,
                backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
                borderColor: '#CCC',
                borderWidth: 1,
                shadow: false
            },
            tooltip: {
                headerFormat: '<b>{point.x}</b><br/>',
                pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}'
            },
            credits: {
                enabled: false
            },
            plotOptions: {
                column: {
                    stacking: 'normal',
                    dataLabels: {
                        enabled: true,
                        color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
                    }
                }
            },
            series: []
        });
        var categories = chart.xAxis[0].categories;
        var greatarr = [];
        var goodarr = [];
        var Averagearr = [];
        var Below_Averagearr = [];
        var Badarr = [];
        for (i = 0; i < 10; i++)
        {
            data = $scope.appwise[i];
            categories.push(data.AppName);     
            greatarr.push(data.Great);
            goodarr.push(data.Good);
            Averagearr.push(data.Average);
            Below_Averagearr.push(data.Below_Average);
            Badarr.push(data.Bad);
        }
        chart.addSeries({
            name: 'Great',
            data: greatarr
          });
        chart.addSeries({
            name: 'Good',
            data: goodarr
        });
        chart.addSeries({
            name: 'Average',
            data: Averagearr
        });
        chart.addSeries({
            name: 'Below_Average',
            data: Below_Averagearr
        });
        chart.addSeries({
            name: 'Bad',
            data: Badarr
        });
        //$.each($scope.yearmonthwise, function (item, data) {
  
        //});
    };
    $scope.yearmonthwise = function () {

        $scope.yearmonthwise = $scope.VOCData["YearMonth"];
        var dataSeries = [];
  
       chart= Highcharts.chart('yearmonChart', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Year/Monthly Feedback Received'
            },
            xAxis: {
                categories: [
                    'Jan',
                    'Feb',
                    'Mar',
                    'Apr',
                    'May',
                    'Jun',
                    'Jul',
                    'Aug',
                    'Sep',
                    'Oct',
                    'Nov',
                    'Dec'
                ],
                crosshair: true
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Count(in nos)'
                }
            },
            tooltip: {
                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                    '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
                footerFormat: '</table>',
                shared: true,
                useHTML: true
            },
            credits: {
                enabled: false
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
            series: []
       });
       $.each($scope.yearmonthwise, function (item, data) {
           chart.addSeries({
               name: data.year,
               data: [data.Jan, data.feb,  data.mar,  data.apr, data.may,  data.jun,  data.Jul,  data.aug,  data.sep,  data.oct,  data.nov,  data.dec]
           });               
       });
    }
    $scope.LoadAnalysisDetails = function () {

        $scope.catgWiseData = $scope.VOCData["Response"];
        var dataSeries = [];
        $.each($scope.catgWiseData, function (item, data) {
            dataSeries.push({ "name": data.FeedResponse, "y": data.FeedRespCnt });
        });
        Highcharts.chart('FBCatgChart', {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie'
            },
            exporting: {
                enabled: false
            },
            title: {
                text: 'Category Wise Response'
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            credits: {
                enabled: false
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: '<b>{point.name}</b>: {point.percentage:.1f} %'
                    },
                    showInLegend: true
                }
            },
            series: [{
                name: 'Feedback',
                colorByPoint: true,
                data: dataSeries
            }]
        });

    }
}]);