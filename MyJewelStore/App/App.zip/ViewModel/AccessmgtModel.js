﻿sswapp.controller('AccessmgtModel', ['$scope', '$location', '$http', 'sharedService', function ($scope, $location, $http, sharedService) {
    $scope.reg = "";
    $scope.app = "";
    $("#appform").show();
    $("#regform").hide();
    //$("#deform").hide();
    $("#deform").css('visibility', 'hidden');

    $scope.getTightGroupData = "";
    $scope.securityLevelData = "";
    $scope.showProcDisp;
    $scope.ReqName = "";
    $scope.UserName = "";
    $scope.Tight_Group = "";
    $scope.Security_Level = "";
    $scope.Data_Tablespace = "";
    $scope.Temp_Tablespace = "";
    $scope.MyRequestNo = "";
    $scope.Externa_User = "";
    $scope.TightGroupData = [];
    $scope.TgGridOpt = {
        data: 'TightGroupData',
        enableColumnResize: true,
        multiSelect: true,
        showSelectionCheckbox: true,
        enableVerticalScrollbar: 2,
        enableHorizontalScrollbar: 2,
        columnDefs: [
        { field: 'TIGHT_GROUP_ID', displayName: 'Tight Group ID', visible: false },
        { field: 'TIGHT_GROUP_NAME', displayName: 'Tight Group Name'},
        { field: 'DESCRIPTION', displayName: 'Description' }
        ]
    };

    $scope.AppClicked = function (app) {
        $('#formtitle').text("");
        $("#regform").show();
        $("#appform").hide();
        // $("#deform").hide();
        $("#deform").css('visibility', 'hidden');
        $scope.app = app;
    }
    $scope.RegionClick =function(reg){
        $("#regform").hide();
        $("#appform").hide();
        // $("#deform").show();
        $("#deform").css('visibility', 'visible');

        $scope.reg = reg;
        title ="Access Management - " + $scope.app + " - " + $scope.reg;
        ShowHideFormnavbar(true);
        $('#formtitle').text(title);

        $scope.showProcDisp = sharedService.openWithoutOverlay();
        //updateLoadingText("Loading Tight Groups...");
        $scope.getTightGroup();
       // updateLoadingText("Loading Security Level...");
        $scope.getSecurityLevelGroup($scope.showProcDisp);
    }

    $scope.getTightGroup = function () {
        $http.get("ExternalData/GetTightGroup", {
            params: { }
        }).
              success(function (data) {
                  var jsStr = JSON.stringify(data);
                  $scope.getTightGroupData = $.parseJSON(jsStr);
                  $scope.TightGroupData = $scope.getTightGroupData;
              }).error(function (data, status, headers, config) {
                  alert("error");
                  return status;
              });
    };


    $scope.getSecurityLevelGroup = function (showproc) {
        $http.get("ExternalData/GetSecurityLevel", {
            params: {}
        }).
              success(function (data) {
                  var jsStr = JSON.stringify(data);
                  $scope.securityLevelData = $.parseJSON(jsStr);
                  showproc.close();

              }).error(function (data, status, headers, config) {
                  alert("error");
                  return status;
              });
    };
}]);