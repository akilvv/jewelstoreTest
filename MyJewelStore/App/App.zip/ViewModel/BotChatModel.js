﻿sswapp.controller('BotChatModel', ['$scope', '$location', '$http','sharedService', function ($scope, $location, $http, sharedService) {
}]);