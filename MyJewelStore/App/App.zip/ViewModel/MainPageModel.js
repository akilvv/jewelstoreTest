﻿sswapp.controller('MainPageModel', ['$scope', '$location', '$http', function ($scope, $location, $http) {
    $('#formtitle').text("");
    ShowHideFormnavbar(false);
    $scope.CardClicked = function (apptype) {
        switch (apptype) {
            case "Access":
                window.location = "#/access";
                break;
            case "VOC":
                window.location = "#/vocreport";
                break;
            case "Chatbot":
                window.location = "#/ChaBot";
                break;
        }
    }
    $http.get("Home/GetSessionObject", {
        params: {}
    }).
      success(function (data) {
          var jsStr = JSON.stringify(data);
          SessionJson = $.parseJSON(jsStr);
          $('body').data("sesObj", SessionJson);
          $('#idUserName', 'body').text("Welcome " + SessionJson.userName);
      }).error(function (data, status, headers, config) {

          return status;
      });


}]);